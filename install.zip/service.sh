#!/bin/sh
WORKDIR=$(cd $(dirname $0); pwd)
RAWCONTENT="A simple, decentralized mesh VPN with WireGuard support."
CONFIG=${WORKDIR}/config.toml
link_ip_forward() {
  while [[ ! -f /data/misc/net/rt_tables ]]; do
      sleep 5
  done

  echo 1 > /proc/sys/net/ipv4/ip_forward
  echo 0 > /dev/ip_forward_stub
  chown $(stat -c '%u:%g' /data/misc/net/rt_tables) /dev/ip_forward_stub
  chcon $(stat -Z -c '%C' /data/misc/net/rt_tables) /dev/ip_forward_stub
  mount -o bind /dev/ip_forward_stub /proc/sys/net/ipv4/ip_forward
}

wait_until_login()
{
  # in case of /data encryption is disabled
  while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
  done

  sleep 5

  # we doesn't have the permission to rw "/sdcard" before the user unlocks the screen
  local test_file="/sdcard/Android/.CFMTEST"

  true >"$test_file"

  while [ ! -f "$test_file" ]; do
    true >"$test_file"
    sleep 1
  done

  rm "$test_file"
}

if [ -f "${WORKDIR}/start" ] ; then
  rm -rf ${WORKDIR}/start
  link_ip_forward
  wait_until_login
fi

sed -i "6cdescription=[worked]${RAWCONTENT}" ${WORKDIR}/module.prop

nohup ${WORKDIR}/easytier-core -c ${CONFIG}